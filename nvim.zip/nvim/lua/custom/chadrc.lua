---@type ChadrcConfig
local M = {}

M.ui = { theme = 'sweetpastel' }
M.plugins = 'custom.plugins'

return M
